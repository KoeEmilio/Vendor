<?php

class Tipo_Servicio extends Models
{
    protected $fillable = [
        'Tipo_Servicio',
        'Nombre_Servicio'
    ];

    protected $table = 'tipo_servicio';
}