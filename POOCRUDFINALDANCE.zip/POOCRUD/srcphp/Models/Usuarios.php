<?php

namespace proyecto\Models;

use proyecto\Response\Success;
use proyecto\Models\Personas;
use proyecto\Models\Empleados;


class Usuarios extends Models
{
    protected $fillable = [
        "UsuarioID",
        "Usuario",
        "Contrasena"
    ];

    protected $table = 'Usuarios';

    public function registerE() {
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $stmt = self::$pdo->prepare("CALL RegistrarUsuarioPersonaEmpleado(
            :Nombre,
            :Direccion,
            :Telefono,
            :Correo,
            :Usuario,
            :Contrasena,
            :RFC,
            :Num_Seguro_Social,
            :CURP
        )");

        $stmt->bindParam(':Nombre', $dataObject->Nombre);
        $stmt->bindParam(':Direccion', $dataObject->Direccion);
        $stmt->bindParam(':Telefono', $dataObject->Telefono);
        $stmt->bindParam(':Correo', $dataObject->Correo);
        $stmt->bindParam(':Usuario', $dataObject->Usuario);
        $stmt->bindParam(':Contrasena', $dataObject->Contrasena);
        $stmt->bindParam(':RFC', $dataObject->RFC);
        $stmt->bindParam(':Num_Seguro_Social', $dataObject->Num_Seguro_Social);
        $stmt->bindParam(':CURP', $dataObject->CURP);

        $stmt->execute();

        return (new Success("Usuario registrado con éxito"))->Send();

    }

    public function registerC() {
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $stmt = self::$pdo->prepare("CALL RegistrarUsuarioPersonaCliente(
            :Nombre,
            :Direccion,
            :Telefono,
            :Correo,
            :Usuario,
            :Contrasena,
            :Tipo_Cliente,
            :Nombre_empresa
        )");

        $stmt->bindParam(':Nombre', $dataObject->Nombre);
        $stmt->bindParam(':Direccion', $dataObject->Direccion);
        $stmt->bindParam(':Telefono', $dataObject->Telefono);
        $stmt->bindParam(':Correo', $dataObject->Correo);
        $stmt->bindParam(':Usuario', $dataObject->Usuario);
        $stmt->bindParam(':Contrasena', $dataObject->Contrasena);
        $stmt->bindParam(':Tipo_Cliente', $dataObject->Tipo_Cliente);
        $stmt->bindParam(':Nombre_empresa', $dataObject->Nombre_empresa);
        

        $stmt->execute();

        return (new Success("Usuario registrado con éxito"))->Send();

    }
}