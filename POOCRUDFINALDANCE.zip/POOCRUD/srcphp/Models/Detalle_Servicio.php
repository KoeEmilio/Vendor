<?php

namespace proyecto\Models;

use proyecto\Response\Success;

class Detalle_Servicio extends Models
{
    protected $fillable = [
        'OrdenID',
        'Fecha_Entrega',
        'Servicio_Dado',
        'Costo_Mano_Obra',
        'Fin_Garantia'
    ];

    protected $table = 'Detalle_Servicio';

    public function registerOS() {
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $stmt = self::$pdo->prepare("CALL RegistrarOrdenServicio(
            :Empleado_Que_Atendera,
            :Vehiculo,
            :Motivo,
            :Estado,
            :Cita
        )");

        $stmt->bindParam(':Empleado_Que_Atendera', $dataObject->Empleado_Que_Atendera);
        $stmt->bindParam(':Vehiculo', $dataObject->Vehiculo);
        $stmt->bindParam(':Motivo', $dataObject->Motivo);
        $stmt->bindParam(':Estado', $dataObject->Estado);
        $stmt->bindParam(':Cita', $dataObject->Cita);

        $stmt->execute();

        return (new Success("Usuario registrado con éxito"))->Send();

    }
}