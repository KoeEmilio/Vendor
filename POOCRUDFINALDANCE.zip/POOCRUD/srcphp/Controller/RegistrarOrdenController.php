<?php

namespace proyecto\Controller;

use proyecto\Models\Orden_Servicio;
use proyecto\Response\Success;
use proyecto\Response\Error;

class RegistrarOrdenController
{
    public function register() {
        try {
            // Obtener el cuerpo de la solicitud
            $JSONData = file_get_contents("php://input");
            $dataObject = json_decode($JSONData);

            // Crear una nueva instancia del modelo Orden_Servicio
            $newOrden = new Orden_Servicio();

            // Asignar los valores desde la solicitud a los atributos del modelo
            $newOrden->Empleado_Que_Atendera = $dataObject->Empleado_Que_Atendera;
            $newOrden->Vehiculo = $dataObject->Vehiculo;
            $newOrden->Motivo = $dataObject->Motivo;
            $newOrden->Cita = isset($dataObject->Cita) ? $dataObject->Cita : null; // Manejar la cita opcionalmente
            $newOrden->Estado = $dataObject->Estado;

            // Guardar el nuevo registro en la base de datos
            $newOrden->save();

            // Devolver los datos de la nueva orden registrada
            return (new Success($newOrden))->Send();

        } catch (Exception $e) {
            // Manejar cualquier error que ocurra durante el proceso
            return (new Error($e->getMessage()))->Send();
        }
    }
}