<?php

namespace proyecto\Models;

use proyecto\Response\Success;
use proyecto\Models\Table;

class Servicios extends Models
{
    protected $fillable = [
        'ServicioID',
        'Nombre_Servicio',
        'Descripcion',
        'Costo_Servicio',
        'Tipo_ServicioID'
    ];

    protected $table = 'Servicios';

    public function mostrarServicios() {
        $tablaCitas = new Table();
        $todasLasCitas = $tablaCitas->query("
        select  Servicios.ServicioID, Servicios.Nombre_Servicio
        , Servicios.Descripcion, Servicios.Costo_Servicio, Tipo_Servicio.Nombre_Servicio as Tipo_Servicio
        from Servicios
        INNER JOIN Tipo_Servicio on Tipo_Servicio.Tipo_ServicioID = Servicios.Tipo_ServicioID");
        return (new Success($todasLasCitas))->send();
    }

}