<?php

namespace proyecto\Models;

use proyecto\Response\Success;

class Detalle_Refaccion extends Models
{
    protected $fillable = [
        'OrdenID',
        'Nombre_Refaccion',
        'Marca',
        'Cantidad',
        'Precio',
        'Comprador'
    ];

    protected $table = 'Detalle_Refaccion';

    public function registerDR() {
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $stmt = self::$pdo->prepare("CALL RegistrarDetalleRefaccion(
            :OrdenID,
            :Nombre_Refaccion,
            :Marca,
            :Cantidad,
            :Precio,
            :Comprador
        )");

        $stmt->bindParam(':OrdenID', $dataObject->OrdenID);
        $stmt->bindParam(':Nombre_Refaccion', $dataObject->Nombre_Refaccion);
        $stmt->bindParam(':Marca', $dataObject->Marca);
        $stmt->bindParam(':Cantidad', $dataObject->Cantidad);
        $stmt->bindParam(':Precio', $dataObject->Precio);
        $stmt->bindParam(':Comprador', $dataObject->Comprador);

        $stmt->execute();

        return (new Success("Usuario registrado con éxito"))->Send();

    }
}