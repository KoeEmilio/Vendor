<?php

namespace proyecto\Models;

use proyecto\Models\Table;
use proyecto\Response\Success;

class Citas extends Models
{
    
    protected $filleable = ["CitaID", "ClienteID","Fecha_Cita", "Hora_Cita","Estado",];
    protected $table ="Citas";
}