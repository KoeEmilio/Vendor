<?php

namespace proyecto\Models;

use PDO;
use proyecto\Auth;
use proyecto\Response\Failure;
use proyecto\Response\Response;
use proyecto\Response\Success;

class User extends Models
{
    public $user = "";
    public $contrasena = "";
    public $nombre = "";
    public $edad = "";
    public $correo = "";
    public $apellido = "";

    public $id = "";

    /**
     * @var array
     */
    protected $fillable = [
        "nombre",
        "edad",
        "correo",
        "apellido",
        "contrasena",
        "user"
    ];

    protected $table = "usuarios";

    public static function auth($Usuario, $Contrasena)
    {
        $class = get_called_class();
        $c = new $class();
    
        // Define la clave de encriptación utilizada para AES
        $clave_encriptacion = 'RATATONGA';
    
        try {
            // Consulta SQL para autenticar al usuario
            $stmt = self::$pdo->prepare("
                SELECT
                    Personas.PersonaID,
                    Personas.Nombre,                               
                    Personas.Correo,                               
                    Usuarios.UsuarioID,                          
                    Roles.Rol AS Rol,                       
                    CAST(AES_DECRYPT(Usuarios.Contrasena, :clave_encriptacion) AS CHAR) AS Contrasena
                FROM Usuarios
                INNER JOIN Personas ON Usuarios.UsuarioID = Personas.PersonaID
                INNER JOIN Rol_Usuario ON Usuarios.UsuarioID = Rol_Usuario.Usuario
                INNER JOIN Roles ON Rol_Usuario.Rol = Roles.RolesID
                WHERE Usuarios.Usuario = :Usuario
            ");
    
            $stmt->bindParam(':Usuario', $Usuario);
            $stmt->bindParam(':clave_encriptacion', $clave_encriptacion);
            $stmt->execute();
    
            $resultado = $stmt->fetch(PDO::FETCH_OBJ);
    
            // Verifica si se obtuvo un resultado
            if ($resultado) {
                // Imprimir para depuración
                var_dump($resultado);
    
                // Verifica si la contraseña es correcta
                if ($resultado->Contrasena === $Contrasena) {
                    // Generar el token con el ID y el Rol
                    $token = Auth::generateToken([
                        'id' => $resultado->UsuarioID,
                        'rol' => $resultado->Rol
                    ]);
                    var_dump($token); // Verificar que el token es un string y tiene un formato correcto
                    
                    // Retornar éxito con datos completos
                    return [
                        'success' => true,
                        'usuario' => [
                            'Nombre' => $resultado->Nombre,
                            'Correo' => $resultado->Correo,
                            'UsuarioID' => $resultado->UsuarioID,
                            'PersonaID' => $resultado->PersonaID,
                            'Rol' => $resultado->Rol
                        ],
                        '_token' => $token
                    ];
                } else {
                    // Contraseña incorrecta
                    return [
                        'success' => false,
                        'msg' => "Credenciales inválidas."
                    ];
                }
            } else {
                // No se encontró el usuario
                return [
                    'success' => false,
                    'msg' => "Usuario no encontrado."
                ];
            }
        } catch (\Exception $e) {
            return [
                'success' => false,
                'msg' => $e->getMessage()
            ];
        }
    }
    

}