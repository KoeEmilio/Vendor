<?php

namespace proyecto\Models;

class Clientes extends Models{

    protected $filleable = ["ClienteID","PersonaID","Tipo_Cliente","Fecha_Registro","Nombre_empresa"];
    protected $table = "Clientes";
}