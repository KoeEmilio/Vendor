<?php

namespace proyecto\Controller;
use PDO;
use proyecto\Models\Citas;
use proyecto\Models\Personas;
use proyecto\Models\Horarios;
use proyecto\Models\Empleados;
use proyecto\Models\Clientes;
use proyecto\Response\Success;
use proyecto\Models\Table;
use proyecto\Models\Orden_Servicio;


class CitasController
{

 
    public function citasconfirmadas() {
        $tablacitas = new Table();
        $citasconfirmadas = $tablacitas->query("        SELECT Personas.Nombre AS Nombre_Persona, Citas.Fecha_Cita, Horarios.Hora AS Hora_Cita
        FROM  Citas 
        JOIN Personas ON Citas.ClienteID = Personas.PersonaID 
        JOIN Horarios ON Citas.Hora_Cita = Horarios.Hora
        WHERE Citas.Estado = 'Confirmada'");
        return (new Success($citasconfirmadas))->send();
    }

    public function registerCita() {
        try {
            $JSONData = file_get_contents("php://input");
            $dataObject = json_decode($JSONData);
    
            $newCita = new Citas();
            $newCita->Fecha_Cita = $dataObject->Fecha_Cita;
            $newCita->Hora_Cita = $dataObject->Hora_Cita;
            $newCita->save();
    
            return (new Success($newCita))->Send();
    
        } catch (Exception $e) {
            return (new Error($e->getMessage()))->Send();
        }
    }

        public function mostrarCitas($cliente) {
            $Cliente = intval($cliente);
            $pdo = $this->PDO();
            $query = "SELECT Citas.CitaID, Citas.Fecha_Cita, Horarios.Hora, Citas.Estado
                    FROM Citas
                    JOIN Horarios ON Citas.Hora_Cita = Horarios.HorarioID
                    JOIN Clientes ON Citas.ClienteID = Clientes.ClienteID
                    WHERE Clientes.PersonaID = :Cliente";
                    
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':Cliente', $Cliente, PDO::PARAM_INT);
            $stmt->execute();
            $citas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            return (new Success($citas))->Send();
        }
    
        private function PDO() {
            try {
                $pdo = new PDO('mysql:host=localhost;dbname=Taller_Mecanico_DeLaRosa', 'Emilio', 'jesusemilio12..');
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                return $pdo;
            } catch (PDOException $e) {
                return json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
        }
    }

    
    
}

