<?php

namespace proyecto\Controller;

use PDO;
use proyecto\Models\OrdenServicio;
use proyecto\Response\Success;
use proyecto\Response\Error;
use proyecto\Models\Table;

class OrdenServicioController
{
    public function mostrarOrdenes() {
        $tablaOrdenes = new Table();
        $todasLasOrdenes = $tablaOrdenes->query("
        SELECT 
                Orden_Servicio.OrdenID, 
                Orden_Servicio.Fecha_Ingreso, 
                Orden_Servicio.Motivo, 
                Orden_Servicio.Estado,
                Personas.Nombre,
                Vehiculos.Marca, 
                Vehiculos.Modelo,
                Citas.Fecha_Cita AS Fecha_Cita
            FROM Orden_Servicio
            INNER JOIN Vehiculos ON Orden_Servicio.Vehiculo = Vehiculos.VehiculoID
            LEFT JOIN Citas ON Orden_Servicio.Citas = Citas.CitaID
            INNER JOIN Personas on Vehiculos.Propietario = Personas.PersonaID
        ");
        return (new Success($todasLasOrdenes))->send();
    }

    public function mostrarVehiculos() {
        $tablaVehiculos = new Table();
        $todosLosVehiculos = $tablaVehiculos->query("
            SELECT 
                Vehiculos.Marca, 
                Vehiculos.Modelo, 
                Vehiculos.Anio, 
                Vehiculos.Color, 
                Vehiculos.Matricula, 
                Vehiculos.Tipo_de_Transmision,
                Personas.Nombre AS Propietario
            FROM Vehiculos
            JOIN Clientes ON Vehiculos.Propietario = Clientes.ClienteID
            JOIN Personas ON Clientes.PersonaID = Personas.PersonaID;
        ");
        return (new Success($todosLosVehiculos))->send();
    }


    public function verCitas() {
        $tablaCitas = new Table();
        $todasLasCitas = $tablaCitas->query("
            SELECT 
                Citas.Fecha_Cita, 
                Horarios.Hora,
                Citas.Estado,
                Personas.Nombre AS Cliente
            FROM Citas
        INNER JOIN Clientes ON Citas.ClienteID = Clientes.ClienteID
        INNER JOIN Personas ON Clientes.PersonaID = Personas.PersonaID
        INNER JOIN Horarios on Horarios.HorarioID = Citas.Hora_Cita;
        ");
        return (new Success($todasLasCitas))->send();
    }

    public function registrarOrden() {
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $nuevaOrden = new OrdenServicio();
        $nuevaOrden->Empleado_Que_Atendera = $dataObject->Empleado;
        $nuevaOrden->Vehiculo = $dataObject->Vehiculo;
        $nuevaOrden->Motivo = $dataObject->Motivo;
        $nuevaOrden->Cita = $dataObject->Cita;
        $nuevaOrden->Estado = $dataObject->Estado;
        $nuevaOrden->save();

        return (new Success($nuevaOrden))->send();
    }

    public function actualizarEstado($ordenID) {
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $orden = OrdenServicio::find($ordenID);
        if ($orden) {
            $orden->Estado = $dataObject->Estado;
            $orden->save();
            return (new Success($orden))->send();
        } else {
            return (new Error("Orden de Servicio no encontrada"))->send();
        }
    }


    public function misOrdenes($persona) {
        $Persona = intval($persona);
        $pdo = $this->PDO();
        $query = "SELECT Orden_Servicio.Fecha_Ingreso, Vehiculos.Marca, Vehiculos.Modelo, Orden_Servicio.Motivo, Orden_Servicio.Estado
                FROM Orden_Servicio
                JOIN Vehiculos ON Orden_Servicio.Vehiculo = Vehiculos.VehiculoID
                JOIN Clientes ON Vehiculos.Propietario = Clientes.ClienteID
                WHERE Clientes.PersonaID = :Persona";
                
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':Persona', $Persona, PDO::PARAM_INT);
        $stmt->execute();
        $ordenes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return (new Success($ordenes))->Send();
    }

    private function PDO() {
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=Taller_Mecanico_DeLaRosa', 'Emilio', 'jesusemilio12..');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (PDOException $e) {
            return json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
        }
    }
}


