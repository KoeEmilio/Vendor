<?php

namespace proyecto\Controller;
use PDO;
use proyecto\Models\Vehiculos;
use proyecto\Response\Success;
use proyecto\Models\Table;

class VehiculosController
{

    public function misVehiculos($propietario) {
        $Propietario = intval($propietario);
        $pdo = $this->PDO();
        $query = "SELECT Vehiculos.VehiculoID, Vehiculos.Marca, Vehiculos.Modelo, Vehiculos.Anio, Vehiculos.Color,
        Vehiculos.Matricula, Vehiculos.Tipo_de_Transmision,
                Personas.Nombre AS Propietario
                FROM Vehiculos 
                JOIN Clientes ON Vehiculos.Propietario = Clientes.ClienteID
                JOIN Personas ON Clientes.PersonaID = Personas.PersonaID
                WHERE Personas.PersonaID = :Propietario";
                
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':Propietario', $Propietario, PDO::PARAM_INT);
        $stmt->execute();
        $vehiculos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return (new Success($vehiculos))->Send();
    }


    public function mostrarvehiculos(){

        $tablavehiculos= new Table();
        $todoslosvehiculos = $tablavehiculos -> query("SELECT Vehiculos.VehiculoID, Vehiculos.Marca, Vehiculos.Modelo, Vehiculos.Anio, Vehiculos.Color, Vehiculos.Matricula,Vehiculos.Tipo_de_Transmision,
        Personas.Nombre AS Propietario
        FROM Vehiculos 
        JOIN Clientes  ON Vehiculos.Propietario = Clientes.ClienteID
        JOIN Personas  ON Clientes.PersonaID = Personas.PersonaID;");
        
        $success = new Success($todoslosvehiculos);
        return $success -> send();

    }
    public function register() {
        try {
            $JSONData = file_get_contents("php://input");
            $dataObject = json_decode($JSONData);
    
            $newVehiculo = new Vehiculos();
            $newVehiculo->Marca = $dataObject->Marca;
            $newVehiculo->Modelo = $dataObject->Modelo;
            $newVehiculo->Anio = $dataObject->Anio;
            $newVehiculo->Color = $dataObject->Color;
            $newVehiculo->Matricula = $dataObject->Matricula;
            $newVehiculo->Propietario = $dataObject->Propietario; // ID del propietario
            $newVehiculo->Tipo_de_Transmision = $dataObject->Tipo_de_Transmision;
            $newVehiculo->Tipo_de_vehiculo_Empresarial = $dataObject->Tipo_de_vehiculo_Empresarial;
            $newVehiculo->Numero_de_Unidad = $dataObject->Numero_de_Unidad;
            $newVehiculo->save();
    
            // Devolver los datos del nuevo vehículo
            return (new Success($newVehiculo))->Send();
    
        } catch (Exception $e) {
            // Manejar cualquier error que ocurra durante el proceso
            return (new Error($e->getMessage()))->Send();
        }
    }

    public function ActualizarVehiculos() {
        
        $JSONData = file_get_contents("php://input");
        $data = json_decode($JSONData, true);
    
        if (!$data) {
            return json_encode(["error" => "No se recibieron datos."]);
        }
        $vehiculoID = $data['VehiculoID'];
        $stmt = $this->PDO()->prepare("UPDATE Vehiculos SET Marca = :Marca, Modelo = :Modelo, Anio = :Anio, Matricula = :Matricula, Color = :Color WHERE VehiculoID = :VehiculoID");
    
        $stmt->bindParam(':Marca', $data['Marca']);
        $stmt->bindParam(':Modelo', $data['Modelo']);
        $stmt->bindParam(':Anio', $data['Anio']);
        $stmt->bindParam(':Matricula', $data['Matricula']);
        $stmt->bindParam(':Color', $data['Color']);
        $stmt->bindParam(':VehiculoID', $vehiculoID);
    
        
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            return json_encode(["message" => "Cliente actualizado correctamente."]);
        } else {
            return json_encode(["message" => "No se pudo actualizar el cliente o no hubo cambios."]);
        }
    }
    
    private function PDO() {
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=taller_mecanico_delarosa', 'Emilio', 'jesusemilio12..');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (PDOException $e) {
            return json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
        }
    }
}