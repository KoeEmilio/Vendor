<?php

namespace proyecto;
require("../vendor/autoload.php");

use proyecto\Controller\crearPersonaController;
use proyecto\Models\User;
use proyecto\Models\Personas;
use proyecto\Response\Failure;
use proyecto\Response\Success;
use proyecto\Models\Servicios;
use proyecto\Controller\PersonasController;
use proyecto\Controller\EmpleadosController;
use proyecto\Controller\VehiculosController;
use proyecto\Controller\UsuariosController;
use proyecto\Controller\LoginController;
use proyecto\Controller\OrdenServicioController;
use proyecto\Controller\CitasController;
use proyecto\Controller\RegistrarOrdenController;
use proyecto\Controller\DetalleServicioController;
use proyecto\Models\Usuarios;
use proyecto\Models\Detalle_Servicio;
use proyecto\Models\Detalle_Refaccion;
use PDO;

Router::get('/misordenes/$persona', [OrdenServicioController::class, 'misOrdenes']);

Router::get('/miscitas/$cliente', [CitasController::class, 'mostrarCitas']);

Router::get('/misvehiculos/$propietario', [VehiculosController::class, 'misVehiculos']);

Router::post('/registrarDetalle',[Detalle_Refaccion::class,'registerDR']);

Router::post('/registrarOrden',[Detalle_Servicio::class,'registerOS']);

Router::get('/citasconfirmadas',[CitasController::class,'citasconfirmadas']);

Router::get('/refacciones',[DetalleServicioController::class,'verrefaccion']);

Router::get('/detalles',[DetalleServicioController::class,'verDetalles']);

Router::get('/misordenes',[DetalleServicioController::class,'misOrdenes']);

Router::get('/miscitas', [CitasController::class, "mostrarCitas"]);

Router::get('/ordenespendientes', [DetalleServicioController::class, "ordenespendientes"]);

Router::post('/registercita',[CitasController::class,'registerCita']);

Router::get('/vercitas',[CitasController::class,'citasconfirmadas']);

Router::put('/actualizarservicios',[SpecificController::class,'ActualizarServicios']);

Router::get('/servicios',[Servicios::class,'mostrarServicios']);

Router::get('/citass',[OrdenServicioController::class,'verCitas']);

Router::get('/ordenes',[OrdenServicioController::class,'mostrarOrdenes']);

Router::put('/actualizarempleados',[EmpleadosController::class,'ActualizarEmpleados']);

Router::post('/login',[LoginController::class,'login']);

Router::post('/registrousuario',[Usuarios::class,'registerE']);

Router::post('/registrousuarioC',[Usuarios::class,'registerC']);

Router::post('/empleado',[EmpleadosController::class,'register']);

Router::post('/registrovehiculos',[VehiculosController::class,'register']);

Router::post('/ingresaempleado', [EmpleadosController::class, "registroempleado"]);

Router::put('/actualizarclientes',[PersonasController::class,'ActualizarClientes']);

Router::get('/personaid',[PersonasController::class,'buscarpersona']);

Router::get('/clientes',[PersonasController::class,'mostrarclientes']);

Router::get('/empleadoss',[EmpleadosController::class,'mostrarempleados']);

Router::get('/pagos',[PersonasController::class,'mostrarpagos']);

Router::get('/vehiculos',[VehiculosController::class,'mostrarvehiculos']);

Router::get('/crearpersona', [crearPersonaController::class, "crearPersona"]);

Router::put('/actualizarvehiculos',[VehiculosController::class,'ActualizarVehiculos']);

Router::get('/usuario/buscar/$id', function ($id) {

    $user= User::find($id);
    if(!$user)
    {
        $r= new Failure(404,"no se encontro el usuario");
        return $r->Send();
    }
$r= new Success($user);
    return $r->Send();


});
Router::get('/respuesta', [crearPersonaController::class, "response"]);
Router::any('/404', '../views/404.php');
