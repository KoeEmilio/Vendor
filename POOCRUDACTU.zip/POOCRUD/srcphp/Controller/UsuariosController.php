<?php

namespace proyecto\Controller;

use proyecto\Models\Usuarios;
use proyecto\Models\Table;
use proyecto\Models\Personas;
use proyecto\Models\Empleados;
use proyecto\Response\Success;
use PDO;

class UsuariosController{


    }

