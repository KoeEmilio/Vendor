<?php

namespace proyecto\Models;

class Tipo_Servicio extends Models
{
    protected $fillable = [
        'Tipo_ServicioID',
        'Nombre_TS',
        'Garantia'
    ];

    protected $table = 'TIPO_SERVICIO';
}