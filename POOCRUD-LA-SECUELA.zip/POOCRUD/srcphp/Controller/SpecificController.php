<?php


namespace proyecto\Controller;

use PDO;
use proyecto\Response\Successs;
use proyecto\Models\Tipo_servicio;

class SpecificController
{

    public function ActualizarServicios() {
        
        $JSONData = file_get_contents("php://input");
        $data = json_decode($JSONData, true);
    
        if (!$data) {
            return json_encode(["error" => "No se recibieron datos."]);
        }
        $servicioID = $data['ServicioID'];
        $stmt = $this->PDO()->prepare("UPDATE Servicios SET Nombre_Servicio = :Nombre_Servicio, Descripcion = :Descripcion, Costo_Servicio = :Costo_Servicio  WHERE ServicioID = :ServicioID");
    
        $stmt->bindParam(':Nombre_Servicio', $data['Nombre_Servicio']);
        $stmt->bindParam(':Descripcion', $data['Descripcion']);
        $stmt->bindParam(':Costo_Servicio', $data['Costo_Servicio']);
        $stmt->bindParam(':ServicioID', $servicioID);
    
        
        $stmt->execute();

        

        if (isset($data['Tipo_Cliente'])) {
            $stmtClientes = $this->PDO()->prepare("UPDATE Tipo_Servicio SET Nombre_TS = :Nombre_TS WHERE Tipo_ServicioID = :Tipo_ServicioID");
            $stmtClientes->bindParam(':Tipo_ServicioID', $data['Tipo_ServicioID']);
            $stmtClientes->bindParam(':ServicioID', $servicioID);

            $stmtClientes->execute();
        }
        
        if ($stmt->rowCount() > 0) {
            return json_encode(["message" => "Cliente actualizado correctamente."]);
        } else {
            return json_encode(["message" => "No se pudo actualizar el cliente o no hubo cambios."]);
        }
    }
    
    private function PDO() {
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=taller_mecanico_delarosa', 'Emilio', 'jesusemilio12..');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (PDOException $e) {
            return json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
        }
    }
}