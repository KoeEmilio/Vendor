<?php

namespace proyecto\Controller;

use proyecto\Models\Table;
use proyecto\Models\Personas;
use proyecto\Models\Empleados;
use PDO;
use PDOException;
use proyecto\Response\Success;

class EmpleadosController
{

    public function mostrarempleados(){
        
        $tablaempleados= new Table();
        $todoslosempleados = $tablaempleados -> query("SELECT Personas.PersonaID, Personas.Nombre,Personas.Telefono,Personas.Correo,Personas.Direccion,Empleados.Estado,
        COUNT(Orden_Servicio.OrdenID) AS Ordenes_Pendientes
        FROM Empleados 
        INNER JOIN Personas  ON Empleados.Persona_Empleado = Personas.PersonaID
        INNER JOIN Usuarios on Usuarios.UsuarioID = Personas.Persona_Usuario
        INNER JOIN Rol_Usuario on Usuarios.UsuarioID = Rol_Usuario.Usuario
        LEFT JOIN Orden_Servicio  ON Empleados.EmpleadoID = Orden_servicio.Empleado_Que_Atendera 
        where Rol_Usuario.Rol = 2
        GROUP BY empleados.EmpleadoID, personas.Nombre, personas.Telefono, personas.Correo, personas.Direccion, empleados.Estado;");
        
        $success = new Success($todoslosempleados);
        return $success -> send();
    }
    

    public function register(){

        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $newPersona = new Personas();
        $newPersona->PersonaID = $dataObject->PersonaID;
        $newPersona->Nombre = $dataObject->Nombre;
        $newPersona->Direccion = $dataObject->Direccion;
        $newPersona->Telefono = $dataObject->Telefono;
        $newPersona->Correo = $dataObject->Correo; // Asignar el nombre de usuario
        $newPersona->save();

        // Obtener el ID de la nueva persona creada
        $personaID = $newPersona->PersonaID;

        $newEmpleado = new Empleados();
        $newEmpleado->EmpleadoID = $dataObject->EmpleadoID; // Asignar el ID del empleado
        $newEmpleado->RFC = $dataObject->RFC;
        $newEmpleado->Num_Seguro_Social = $dataObject->Num_Seguro_Social;
        $newEmpleado->CURP = $dataObject->CURP;
        $newEmpleado->Persona_Empleado = $personaID; // Asignar el ID de la persona recién creada
        $newEmpleado->Estado = $dataObject -> Estado; 
        $newEmpleado->save();

    

        // Devolver los datos del nuevo empleado
        return (new Success($newEmpleado))->Send();
    }

    public function mostrarclientes(){
        
        $tablapersona= new Table();
        $todaslaspersonas = $tablapersona -> query("select Personas.PersonaID , Personas.Nombre , Personas.Correo , Personas.Telefono,
        Clientes.Tipo_Cliente
        from Personas
        inner join Clientes on Personas.PersonaID = Clientes.PersonaID");
        
        $success = new Success($todaslaspersonas);
        return $success -> send();

    
    }

    public function ActualizarEmpleados() {
        
        $JSONData = file_get_contents("php://input");
        $data = json_decode($JSONData, true);
    
        if (!$data) {
            return json_encode(["error" => "No se recibieron datos."]);
        }
        $personaID = $data['PersonaID'];
        $stmt = $this->PDO()->prepare("UPDATE Personas SET Nombre = :Nombre, Correo = :Correo, Telefono = :Telefono, Direccion = :Direccion WHERE PersonaID = :PersonaID");
    
        $stmt->bindParam(':Nombre', $data['Nombre']);
        $stmt->bindParam(':Correo', $data['Correo']);
        $stmt->bindParam(':Telefono', $data['Telefono']);
        $stmt->bindParam(':Direccion', $data['Direccion']);
        $stmt->bindParam(':PersonaID', $personaID);
    
        
        $stmt->execute();

        
        if ($stmt->rowCount() > 0) {
            return json_encode(["message" => "Cliente actualizado correctamente."]);
        } else {
            return json_encode(["message" => "No se pudo actualizar el cliente o no hubo cambios."]);
        }
    }
    
    private function PDO() {
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=taller_mecanico_delarosa', 'Emilio', 'jesusemilio12..');
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (PDOException $e) {
            return json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
        }
    }
}
