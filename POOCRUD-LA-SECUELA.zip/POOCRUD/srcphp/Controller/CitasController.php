<?php

namespace proyecto\Controller;
use PDO;
use proyecto\Models\Citas;
use proyecto\Models\Personas;
use proyecto\Models\Horarios;
use proyecto\Models\Empleados;
use proyecto\Models\Clientes;
use proyecto\Response\Success;
use proyecto\Models\Table;
use proyecto\Models\Orden_Servicio;


class CitasController
{

 
    public function citasconfirmadas() {
        $tablacitas = new Table();
        $citasconfirmadas = $tablacitas->query("SELECT Personas.Nombre AS Nombre_Persona, Citas.Fecha_Cita, Horarios.Hora AS Hora_Cita,  Personas_Empleados.Nombre AS Mecanico
        FROM  Citas JOIN Personas ON Citas.ClienteID = Personas.PersonaID JOIN Horarios ON Citas.Hora_Cita = Horarios.Hora
        JOIN Empleados ON Citas.MecanicoID = Empleados.Persona_Empleado JOIN Personas AS Personas_Empleados ON Empleados.Persona_Empleado = Personas_Empleados.PersonaID
        WHERE Citas.Estado = 'Confirmada';");
        return (new Success($citasconfirmadas))->send();
    }

    public function registerCita() {
        try {
            $JSONData = file_get_contents("php://input");
            $dataObject = json_decode($JSONData);
    
            $newCita = new Citas();
            $newCita->Fecha_Cita = $dataObject->Fecha_Cita;
            $newCita->Hora_Cita = $dataObject->Hora_Cita;
            $newCita->save();
    
            return (new Success($newCita))->Send();
    
        } catch (Exception $e) {
            return (new Error($e->getMessage()))->Send();
        }
    }

        public function mostrarCitas($userId) {
            $pdo = $this->PDO();
            $query = "SELECT Citas.CitaID, Citas.Fecha_Cita, Horarios.Hora, Citas.Estado, Empleados.Persona_Empleado AS Mecanico
                    FROM Citas
                    JOIN Horarios ON Citas.Hora_Cita = Horarios.HorarioID
                    JOIN Empleados ON Citas.MecanicoID = Empleados.EmpleadoID
                    JOIN Clientes ON Citas.ClienteID = Clientes.ClienteID
                    WHERE Clientes.PersonaID = :userId";
                    
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
            $stmt->execute();
            $citas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            return (new Success($citas))->Send();
        }
    
        private function PDO() {
            try {
                $pdo = new PDO('mysql:host=localhost;dbname=Taller_Mecanico_DeLaRosa', 'Emilio', 'jesusemilio12..');
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                return $pdo;
            } catch (PDOException $e) {
                return json_encode(['error' => 'Error de conexión: ' . $e->getMessage()]);
        }
    }

    
    
}

