<?php

namespace proyecto\Controller;

use proyecto\Models\Orden_Servicio;
use proyecto\Models\Vehiculos;
use proyecto\Response\Success;
use proyecto\Response\Error;
use proyecto\Models\Table;
use proyecto\Models\Detalle_Refaccion;
use PDOException;

class DetalleServicioController
{

public function ordenespendientes() {
$tablaordenservicio = new Table();
$ordenespendientes = $tablaordenservicio->query("SELECT Orden_Servicio.OrdenID,CONCAT(Vehiculos.Marca, ' ', Vehiculos.Modelo, ' ', Vehiculos.Anio, ' ', Vehiculos.Color, ' - Matrícula: ', Vehiculos.Matricula) AS Datos_Vehiculo,Orden_Servicio.Estado
FROM Orden_Servicio
INNER JOIN Vehiculos ON Orden_Servicio.Vehiculo = Vehiculos.VehiculoID
WHERE Orden_Servicio.Estado = 'Pendiente';");
return (new Success($ordenespendientes))->send();
                                    }


                                    public function verdetalles() {
                                        $tabladetalles = new Table();
                                        $verdetalles = $tabladetalles->query("SELECT 
                                        Orden_Servicio.OrdenID,
                                        Orden_Servicio.Fecha_Ingreso,
                                        Orden_Servicio.Motivo,
                                        Orden_Servicio.Estado AS Estado_Orden,
                                        Detalle_Servicio.Fecha_Entrega,
                                        Detalle_Servicio.Servicio_Dado,
                                        Servicios.Nombre_Servicio,
                                        Servicios.Descripcion AS Descripcion_Servicio,
                                        Detalle_Servicio.Costo_Mano_Obra,
                                        Detalle_Servicio.Fin_Garantia,
                                        Vehiculos.Marca,
                                        Vehiculos.Modelo,
                                        Vehiculos.Anio,
                                        Vehiculos.Color,
                                        Vehiculos.Matricula
                                    FROM 
                                        Orden_Servicio
                                    INNER JOIN 
                                        Detalle_Servicio ON Orden_Servicio.OrdenID = Detalle_Servicio.OrdenID
                                    INNER JOIN 
                                        Servicios ON Detalle_Servicio.Servicio_Dado = Servicios.ServicioID
                                    INNER JOIN 
                                        Vehiculos ON Orden_Servicio.Vehiculo = Vehiculos.VehiculoID;");
                                        return (new Success($verdetalles))->send();
                                        }
                                        public function verrefaccion() {
                                            $tablacitas = new Table();
                                            $verrefaccion = $tablacitas->query("SELECT 
                                    Detalle_Refaccion.OrdenID,
                                    Detalle_Refaccion.Nombre_Refaccion,
                                    Detalle_Refaccion.Marca,
                                    Detalle_Refaccion.Cantidad,
                                    Detalle_Refaccion.Precio,
                                    Detalle_Refaccion.Comprador,
                                    Orden_Servicio.Fecha_Ingreso,
                                    Orden_Servicio.Motivo,
                                    Orden_Servicio.Estado
                                    FROM 
                                    Detalle_Refaccion
                                    JOIN 
                                    Orden_Servicio ON Detalle_Refaccion.OrdenID = Orden_Servicio.OrdenID;");
                                            return (new Success($verrefaccion))->send();
                                        }
                                        public function crearDetalleRefaccion()
                                        {
                                            $dataObject = json_decode(file_get_contents('php://input'));
                                        
                                            if ($dataObject) {
                                                try {
                                                    $newDetalle = new Detalle_Refaccion();
                                                    $newDetalle->OrdenID = $dataObject->OrdenID;
                                                    $newDetalle->Nombre_Refaccion = $dataObject->Nombre_Refaccion;
                                                    $newDetalle->Marca = $dataObject->Marca;
                                                    $newDetalle->Cantidad = $dataObject->Cantidad;
                                                    $newDetalle->Precio = $dataObject->Precio;
                                                    $newDetalle->Comprador = $dataObject->Comprador;
                                                    $newDetalle->save();
                                        
                                                    $success = new Success($newDetalle);
                                                    return $success->send();
                                                } catch (PDOException $e) {
                                                    $error = new Error('Error al guardar el detalle de refacción: ' . $e->getMessage());
                                                    return $error->send();
                                                }
                                            } else {
                                                return (new Error('Datos de entrada inválidos'))->send();
                                            }
                                        }
                                        
                                        
                                    }
