<?php

namespace proyecto\Controller;

use proyecto\Models\Detalle_Refaccion;
use proyecto\Response\Success;
use proyecto\Response\Error;
use PDOException;

class DetalleRefaccionController
{
    public function crearDetalleRefaccion()
    {
        $dataObject = json_decode(file_get_contents('php://input')); // Obtén los datos de la solicitud

        if ($dataObject) {
            try {
                $newDetalle = new Detalle_Refaccion();
                $newDetalle->OrdenID = $dataObject->OrdenID;
                $newDetalle->Nombre_Refaccion = $dataObject->Nombre_Refaccion;
                $newDetalle->Marca = $dataObject->Marca;
                $newDetalle->Cantidad = $dataObject->Cantidad;
                $newDetalle->Precio = $dataObject->Precio;
                $newDetalle->Comprador = $dataObject->Comprador;
                $newDetalle->save();  // Llama al método save para insertar los datos

                $success = new Success($newDetalle);
                return $success->send();
            } catch (PDOException $e) {
                $error = new Error('Error al guardar el detalle de refacción: ' . $e->getMessage());
                return $error->send();
            }
        } else {
            return (new Error('Datos de entrada inválidos'))->send();
        }
    }
}
