<?php

namespace proyecto\Models;

class Horarios extends Models{

    protected $filleable = ["HorarioID","Hora"];
    protected $table = "Horarios";
}