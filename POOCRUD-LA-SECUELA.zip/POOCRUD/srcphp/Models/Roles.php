<?php

class Roles extends Models
{
    protected $fillable = [
        'RolesID',
        'Rol'
    ];

    protected $table ='Roles';
}