<?php

namespace proyecto;

use Carbon\Carbon;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use proyecto\Models\User;

class Auth
{
    private $user;
    private const SECRET_KEY = 'RATATONGA';  // Clave secreta

    /**
     * Genera un token JWT con los datos del usuario y un tiempo de expiración.
     *
     * @param mixed $user
     * @param int $time
     * @return string
     */
    public static function generateToken($user, $time = 3600): string
    {
        $expiration = Carbon::now()->timestamp + $time;
        $payload = [
            'exp' => $expiration,
            'data' => [
                'id' => $user->id,
                'rol' => $user->rol  // Incluir el rol en el payload
            ]
        ];
        return JWT::encode($payload, self::SECRET_KEY, 'HS256');
    }

    /**
     * Obtiene el usuario autenticado utilizando el token JWT.
     *
     * @return mixed|null
     */
    public static function getUser()
    {
        try {
            $jwt = Router::getBearerToken();
            $token = JWT::decode($jwt, new Key(self::SECRET_KEY, 'HS256'));
            return User::find($token->data->id);  // Suponiendo que data es un objeto con un campo 'id'
        } catch (\Exception $e) {
            // Manejo de errores, por ejemplo, token expirado o inválido
            return null;
        }
    }

    /**
     * Obtiene el rol del usuario autenticado utilizando el token JWT.
     *
     * @return string|null
     */
    public static function getUserRole()
    {
        try {
            $jwt = Router::getBearerToken();
            $token = JWT::decode($jwt, new Key(self::SECRET_KEY, 'HS256'));
            return $token->data->rol;  // Retornar el rol del usuario
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Establece el usuario en la sesión.
     *
     * @param mixed $user
     */
    public static function setUser($user): void
    {
        $session = new Session();
        $session->set('user', $user);
    }

    /**
     * Elimina al usuario de la sesión.
     */
    public function clearUser(): void
    {
        $session = new Session();
        $session->remove('user');
    }

    /**
     * Verifica si el usuario tiene un rol específico.
     *
     * @param string $role
     * @return bool
     */
    public static function checkRole($role): bool
    {
        $userRole = self::getUserRole();
        return $userRole === $role;
    }
}
