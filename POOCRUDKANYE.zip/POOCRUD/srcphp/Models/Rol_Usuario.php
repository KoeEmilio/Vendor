<?php

class Rol_Usuario extends Models
{
    protected $fillable = [
        'Rol',
        'Usuario'
    ];

    protected $table = 'Rol_Usuario';
}