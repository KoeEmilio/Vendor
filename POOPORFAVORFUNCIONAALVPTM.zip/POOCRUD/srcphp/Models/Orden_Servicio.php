<?php

namespace proyecto\Models;

class Orden_Servicio extends Models
{
    protected $fillable = [
        'OrdenID',
        'Fecha_Ingreso',
        'Empleado_Que_Atendera',
        'Vehiculo',
        'Motivo',
        'Estado',
        'Citas'
    ];

    protected $table = 'Orden_Servicio';
}