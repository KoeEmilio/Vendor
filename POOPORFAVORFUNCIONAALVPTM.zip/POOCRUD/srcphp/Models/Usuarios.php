<?php

namespace proyecto\Models;

use proyecto\Response\Success;
use proyecto\Models\Personas;
use proyecto\Models\Empleados;


class Usuarios extends Models
{
    protected $fillable = [
        "UsuarioID",
        "Usuario",
        "Contrasena"
    ];

    protected $table = 'Usuarios';

    public function registerE() {
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $stmt = self::$pdo->prepare("CALL RegistrarUsuarioPersonaEmpleado(
            :Nombre,
            :Direccion,
            :Telefono,
            :Correo,
            :Usuario,
            :Contrasena,
            :RFC,
            :Num_Seguro_Social,
            :CURP
        )");

        $stmt->bindParam(':Nombre', $dataObject->Nombre);
        $stmt->bindParam(':Direccion', $dataObject->Direccion);
        $stmt->bindParam(':Telefono', $dataObject->Telefono);
        $stmt->bindParam(':Correo', $dataObject->Correo);
        $stmt->bindParam(':Usuario', $dataObject->Usuario);
        $stmt->bindParam(':Contrasena', $dataObject->Contrasena);
        $stmt->bindParam(':RFC', $dataObject->RFC);
        $stmt->bindParam(':Num_Seguro_Social', $dataObject->Num_Seguro_Social);
        $stmt->bindParam(':CURP', $dataObject->CURP);

        $stmt->execute();

        return (new Success("Usuario registrado con éxito"))->Send();

    }

    public function registerC(){
        
        $JSONData = file_get_contents("php://input");
        $dataObject = json_decode($JSONData);

        $newUsuario = new Usuarios();
        $newUsuario->Usuario = $dataObject->Usuario;
        $newUsuario->Contrasena = password_hash($dataObject->Contrasena, PASSWORD_DEFAULT);


        $newPersona = new Personas();
        $newPersona->Nombre = $dataObject->Nombre;
        $newPersona->Direccion = $dataObject->Direccion;
        $newPersona->Telefono = $dataObject->Telefono;
        $newPersona->Correo = $dataObject->Correo; // Asignar el nombre de usuario
        $newPersona->Usuario_Persona = $dataObject->Usuario_Persona; // Asignar el ID del usuario recién creado
        $newPersona->save();

        // Obtener el ID de la nueva persona creada
        $personaID = $newPersona->PersonaID;

        $newEmpleado = new Clientes();
        $newEmpleado->RFC = $dataObject->RFC;
        $newEmpleado->Num_Seguro_Social = $dataObject->Num_Seguro_Social;
        $newEmpleado->CURP = $dataObject->CURP;
        $newEmpleado->Persona_Empleado = $personaID; // Asignar el ID de la persona recién creada
        $newEmpleado->Estado = $dataObject -> Estado; 
        $newEmpleado->save();

    

        // Devolver los datos del nuevo empleado
        return (new Success($newEmpleado,$newPersona,$newUsuario))->Send();
    }
}