<?php

namespace proyecto\Controller;

use proyecto\Models\Orden_Servicio;
use proyecto\Models\Vehiculos;
use proyecto\Response\Success;
use proyecto\Response\Error;
use proyecto\Models\Table;
use PDOException;

class DetalleServicioController
{

public function ordenespendientes() {
$tablaordenservicio = new Table();
$ordenespendientes = $tablaordenservicio->query("SELECT Orden_Servicio.OrdenID,CONCAT(Vehiculos.Marca, ' ', Vehiculos.Modelo, ' ', Vehiculos.Anio, ' ', Vehiculos.Color, ' - Matrícula: ', Vehiculos.Matricula) AS Datos_Vehiculo,Orden_Servicio.Estado
FROM Orden_Servicio
INNER JOIN Vehiculos ON Orden_Servicio.Vehiculo = Vehiculos.VehiculoID
WHERE Orden_Servicio.Estado = 'Pendiente';");
return (new Success($ordenespendientes))->send();
                                    }
}