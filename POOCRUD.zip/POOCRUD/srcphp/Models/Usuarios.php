<?php

namespace proyecto\Models;

class Usuarios extends Models
{
    protected $fillable = [
        "Usuario",
        "Contrasena"
    ];

    protected $table = 'Usuarios';
}